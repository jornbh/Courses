
#ifndef INRERRUPTS_H
#define INTERRUPTS_H

#define INTERRUPTS 
#define USART_INTERRUPTS






void interrupts_test_interrupts();
void interrupt_init();



#endif