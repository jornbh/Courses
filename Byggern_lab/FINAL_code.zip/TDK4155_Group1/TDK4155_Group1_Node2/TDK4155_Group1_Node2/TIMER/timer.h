/*
 * timer.h
 *
 * Created: 08.11.2017 18:22:24
 *  Author: jornbh
 */ 


#ifndef TIMER_H_
#define TIMER_H_

void timer_init();
void timer_stop();
int timer_get();
void timer_reset();


#endif /* TIMER_H_ */