

#ifndef INTERRUPTS_USART_H
#define INTERRUPTS_USART_H
#include "interrupts.h"

void interrupts_usart_init();




#endif//INTERRUPTS_USART_H