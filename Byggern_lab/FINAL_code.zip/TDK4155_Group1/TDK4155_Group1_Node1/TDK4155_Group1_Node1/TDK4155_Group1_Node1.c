/*
 * TDK4155_Group1_Node1.c
 *
 * Created: 25.10.2017 10:49:44
 *  Author: huberts
 */ 


#include <avr/io.h>

int main(void)
{
    while(1)
    {
        //TODO:: Please write your application code 
    }
}