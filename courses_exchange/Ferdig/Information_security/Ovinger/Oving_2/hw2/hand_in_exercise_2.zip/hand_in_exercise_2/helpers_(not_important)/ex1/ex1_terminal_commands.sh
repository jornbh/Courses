export FLASK_APP=ex1.py
flask run
